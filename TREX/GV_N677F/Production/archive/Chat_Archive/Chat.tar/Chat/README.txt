The "Logs" subdirectory contain all the pertinent log files from T-REX.
 The room names were:  trex, G5, bae146, kingair and dropsonde.

Notes:  Scripts in this directory were originally in the "Logs" subdirectory
         for execution.  "zipem and the second "getem" operation restored the
         original file dates from the chat server (which got reset after a
         local disc "restore" operation, because the restore command did not
         have the option set to preserve file dates).

        Usable chat files (with actual chat messages instead of just logs of
         who came and went and other administrative messages) can be found
         using the following:  grep -l  '<' Logs/*
         (All chat exchanges have "<nick>" at the beginning, where "nick"
         is the nickname of the person chatting.)

Ronald L. Ruth
Thu Jan 11 12:57:14 MST 2007
